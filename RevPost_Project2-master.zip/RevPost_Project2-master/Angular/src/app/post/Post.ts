export class Post {
    post_id: number;
    user_id: number;
    text: string;
    likecount: number;
    constructor() {
        
    }
}