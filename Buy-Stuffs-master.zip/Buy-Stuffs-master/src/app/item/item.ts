export class Item{
    id: number;
    name: String;
    description: String;
    quantity: number;
    price: number;

    constructor(){
        
    }

    
}