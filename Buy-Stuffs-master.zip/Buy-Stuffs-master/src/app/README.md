The items_copy.json file is just a copy of the original state of items.json.
Use items_copy.json to replenish items.json.
Do NOT alter the contents of items_copy.json.
Simply copy the contents of items_copy.json and paste them over the contents of items.json.