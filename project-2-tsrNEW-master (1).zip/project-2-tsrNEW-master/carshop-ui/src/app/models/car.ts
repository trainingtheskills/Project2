export class Car{
    id: number;
    year: number;
    model: string;
    price: number;
    color: string;
    type: string;
    description: string;
    constructor(){}
}