export class JwtAuthenticationRequest {
    username: string;
    password: string;
}