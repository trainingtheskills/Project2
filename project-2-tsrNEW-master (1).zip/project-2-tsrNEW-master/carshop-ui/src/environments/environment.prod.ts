export const environment = {
  production: true,
  API_URL: 'http://localhost:8090/springCarShow/api'
};
