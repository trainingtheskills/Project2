import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-banner',
  templateUrl: './image-banner.component.html',
  styleUrls: ['./image-banner.component.css']
})
export class ImageBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  




}
