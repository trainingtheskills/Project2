export const properties = {

  url: 'http://localhost:8080/Rev_SpringMVC_Hello/user/'

};