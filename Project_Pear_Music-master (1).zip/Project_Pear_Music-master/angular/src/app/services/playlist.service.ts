import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class PlaylistService {

  //create array
  // public books:Book[]=[ {"id":1,"title":"Java","author":"Martin","price":100},
  //                   {"id":2,"title":"javaScript","author":"Mark","price":200},
  //                   {"id":3,"title":"JQuery","author":"Maryin","price":300},
  //                   {"id":4,"title":"The Split in the Universe","author":"Thanos","price":0}];

  
  //return book array
  // getBooks():Book[]{
  //   return this.books;
  // }
  //get all books
  getPlayists():Observable<any>{//asynchronous
    return this._httpService.get("http://localhost:8080/Rev_SpringMVC_Hello/api/playlists");
  }
  constructor(private _httpService:HttpClient) { }
  updateUser(user:User):Observable<any>{
    let body=JSON.parse(JSON.stringify(user));
    console.log(body)
    return this._httpService.put("http://localhost:8080/Rev_SpringMVC_Hello/user/",body);
  }
  getUserById(userId:number):Observable<any>{
    return this._httpService.get("http://localhost:8090/Rev_SpringMVC_Hello/user/"+userId);
  }
// //add a new book
//   addBook(book:Book){
//     let body=JSON.parse(JSON.stringify(book));
//     if(!book.id){
//       console.log("Entered for updates ");
//        return this._httpService.put("http://localhost:8090/Rev_SpringMVC_Hello/api/books",body);
//     }
//     else{
//       console.log("Entered in new");
//       return this._httpService.post("http://localhost:8090/Rev_SpringMVC_Hello/api/books/",body);
//     }
//   }

//   //delete book
//   deleteBook(bookId:number){
//     return this._httpService.delete("http://localhost:8090/Rev_SpringMVC_Hello/api/books/"+bookId);
//   }
  
//   //get a book
//   getBookById(bookId:number):Observable<any>{
//     return this._httpService.get("http://localhost:8090/Rev_SpringMVC_Hello/api/books/"+bookId);
//   }
}
