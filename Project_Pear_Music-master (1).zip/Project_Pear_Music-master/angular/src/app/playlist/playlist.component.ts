import { Component, OnInit } from '@angular/core';
import { Playlist } from '../models/playlist';
import { Library } from '../models/library';
import { User } from '../models/user.model';
import { PlaylistService } from '../services/playlist.service';
import { ContextService } from '../services/context.service';
import { LibraryService } from '../services/library.service';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css']
})
export class PlaylistComponent implements OnInit {
  playlists:Playlist[]; //create a playlist array
  library_entry= new Library;
  statusMessage:string;
  playlist=new Playlist;
  library_entries:Library[]; //create a playlist array

  tempA:  Library[];
  addL:  Library[];
  

  temp_library_entry= new Library;
   temp=new Playlist;
loggedUser=new User;
modUser=new User;

  addPlaylistForm:boolean;
  minusButton:boolean;
  click:boolean;
  onLibraryTable:boolean;
  constructor(private _playService:PlaylistService, private context: ContextService,private _libraryService:LibraryService) { }
    //get all playlists
    getPlaylists():void{
      console.log("Got a Playlist");
      this._playService.getPlayists()
        .subscribe((playlistData)=>this.playlists=playlistData,
          (error)=>{console.log(error);
            this.statusMessage="Problem with service. Please try again later";
                    }
            );     
    }

  // ngOnInit() {
  //   this. getPlaylists();
  // }

    //get all user playlists
    getUserPlaylists():Playlist[]{
      console.log("piiiiiiii");
      console.log(this.context.getUser().playlists);
       this.loggedUser=this.context.getUser();
     return this.loggedUser.playlists;
     
    }

     //get individual book
     getUserById(id:number){
    this._playService.getUserById(id)
    .subscribe(
      (userData)=>{this.modUser=userData;
      this.context.setUser(this.modUser);}),
    (error)=>{
      console.log(error);
      this.statusMessage="Problem with service. Please try again later";
    }
    this.getUserPlaylists();

  }

    getUserLibrary(playlist:Playlist){
      console.log("liiiiiiii" +playlist.name);
      this.click=false;
       this.playlist= playlist;
       this.click=true;
       return this.playlist
     
    }

    
  gettemp(): Playlist {
    return this.temp;
  }

  settemp(temp: Playlist): void {
    this.temp = temp;
  }
    
    addPlaylist():void{
      this.offPlaylistForm();

      console.log("temp "+this.temp.name)
      
      this.addL=[];
      this.playlist=JSON.parse(JSON.stringify(this.temp));
      //this.playlist=this.gettemp();
     
      this.loggedUser.playlists.push(this.playlist);
 
      console.log(this.loggedUser.playlists.length);
      this._playService.updateUser(this.loggedUser)
      .subscribe((response)=>this.loggedUser=response,
      (error)=>{console.log(error);
        this.statusMessage="Problem with service. Please try again later";
                }
        ); 
        console.log(this.modUser.playlists.length);
      this.context.setUser(this.loggedUser);
     // this.ngOnInit();
     this.addL=[];
      this. getUserPlaylists();
      
    }
    addLibrary(playlist:Playlist):void{
      this.onLibraryTable=false
      document.getElementById('addlib-btn').disabled=false;
      
      
     // console.log("addL"+this.addL.length)
      //console.log("PLE"+ playlist.libraryEntries.length)
      //playlist.libraryEntries=this. getUserLibrary(playlist).libraryEntries;
      playlist.libraryEntries=[];
      for(this.library_entry of this.addL){
        playlist.libraryEntries.push(this.library_entry );
    }
     console.log("play_lib_enr"+  playlist.libraryEntries.length);
     // this.loggedUser.playlists.push(this.playlist);
 
      console.log("LG_PL"+this.loggedUser.playlists.length);
      this._playService.updateUser(this.loggedUser)
      .subscribe((response)=>this.loggedUser=response,
      (error)=>{console.log(error);
        this.statusMessage="Problem with service. Please try again later";
                }
        ); 
        console.log(this.modUser.playlists.length);
      this.context.setUser(this.loggedUser);
     // this.ngOnInit();
     this.addL=[];
     this.playlists=[];

     this.library_entries=[];
   this.playlist.libraryEntries=[];
   this.temp.libraryEntries=[];
     this.tempA=[];
      this. getUserPlaylists();
    
    }
    getLibrary():void{
      console.log("Got a library_entry");
      this._libraryService.getLibrary()
        .subscribe((library_entryData)=>this.library_entries=library_entryData,
          (error)=>{console.log(error);
            this.statusMessage="Problem with service. Please try again later";
                    }
            );
            console.log(this.library_entries)
    }
    getRelevantLibrary(playlist:Playlist){
      console.log("this"+playlist.libraryEntries.length);
    
      this.tempA = JSON.parse(JSON.stringify(this.library_entries));
      
      console.log("thistempB"+this.tempA.length); 
      console.log("thisLEB"+this.library_entries.length); 
      for( this.temp_library_entry of playlist.libraryEntries){
         for( this.library_entry of this.library_entries){
        
          if(this.temp_library_entry.title.localeCompare(this.library_entry.title)==0){
            console.log("title"+this.temp_library_entry.title)
            const Index = this.library_entries.indexOf(this.library_entry);
            console.log("index"+Index);
            if(Index!=-1){
              this.tempA.splice(Index, 1);
              
              
            }
           
          }
          
        }
    }
    console.log("thistempA"+this.tempA.length);    
    console.log("thisLEA"+this.library_entries.length);          
    
  
    }
    deleteLibraryEntry(library_entry:Library):void{
      

      console.log(this.library_entry);
        
      const Index = this.loggedUser.playlists.indexOf(this.playlist);
      this.loggedUser.playlists.splice(Index, 1);


         const index = this.playlist.libraryEntries.indexOf(library_entry);
         this.playlist.libraryEntries.splice(index, 1);

        this.loggedUser.playlists.push(this.playlist);
       
          this._playService.updateUser(this.loggedUser)
          .subscribe((response)=>this.loggedUser=response,
          (error)=>{console.log(error);
            this.statusMessage="Problem with service. Please try again later";
                    }
            );  
          
          this.context.setUser(this.loggedUser);
          //this.ngOnInit();
          this. getUserPlaylists();
          
        }
    deletePlaylist():void{
      

  console.log(this.playlist);
    
     const index = this.loggedUser.playlists.indexOf(this.playlist);
     this.loggedUser.playlists.splice(index, 1);
     console.log(this.loggedUser.playlists.length);
   
      this._playService.updateUser(this.loggedUser)
      .subscribe((response)=>this.loggedUser=response,
      (error)=>{console.log(error);
        this.statusMessage="Problem with service. Please try again later";
                }
        );  
      
      this.context.setUser(this.loggedUser);
      //this.ngOnInit();
      this. getUserPlaylists();
      
    }

    onPlaylistForm():boolean{
      this.addPlaylistForm=true;
     
     return this.addPlaylistForm;
 
    }
    offPlaylistForm():boolean{
      this.addPlaylistForm=false
      
     return this.addPlaylistForm;
 
    }
   doalert(y:number,temp_library_entry:Library) {
     console.log(y);
      if (<HTMLInputElement>document.getElementById('chb'+y).checked) {
        document.getElementById('addlib-btn').disabled=true;

      console.log("checked");
      
      console.log("tempA" +this.tempA.length);
      console.log("LE" +temp_library_entry.title);
 
         temp_library_entry.id=null;
      this.addL.push(temp_library_entry);
      console.log("ADDL" +this.addL.length);
     console.log("LEAA" +temp_library_entry.id);
        
      }
      else{
      //  
        const Index = this.addL.indexOf(temp_library_entry);
        this.addL.splice(Index, 1);
        
      }
    }

    dispBtnQ(y:number) { 
      console.log("jake paulQ" +y);
      document.getElementById('buttonQ'+y).setAttribute('style','visibility:visible');
                } 

       hideBtnQ(y:number) { 
      console.log("jake paul" +y);
      document.getElementById('buttonQ'+y).setAttribute('style','visibility:hidden');
                }              
    
    dispBtn(y:number) { 
      console.log("jake paul" +y);
      document.getElementById('button'+y).setAttribute('style','visibility:visible');
                } 

       hideBtn(y:number) { 
      console.log("jake paul" +y);
      document.getElementById('button'+y).setAttribute('style','visibility:hidden');
                }              
    
  ngOnInit() {

   
   this.addL=[];
   this.playlists=[];

   this.library_entries=[];
 this.playlist.libraryEntries=[];
 this.temp.libraryEntries=[];
   this.tempA=[];
   this. getUserPlaylists();
   this.getLibrary();
  this.onLibraryTable=false;
  }




}

