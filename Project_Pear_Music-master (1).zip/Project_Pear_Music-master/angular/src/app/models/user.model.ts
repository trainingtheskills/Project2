import { Playlist } from "./playlist";


export class User {
    userId : Number;
    userName: String;
    firstName: String;
    lastName: String;
    email: String;
    password: String;
    playlists: Playlist[];

}
