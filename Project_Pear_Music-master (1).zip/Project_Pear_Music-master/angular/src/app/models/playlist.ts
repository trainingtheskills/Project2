import { Library } from "./library";

export  class Playlist{
    id:number;
    name: string;
    libraryEntries:Library[]; 
    constructor(){
        
    }
}